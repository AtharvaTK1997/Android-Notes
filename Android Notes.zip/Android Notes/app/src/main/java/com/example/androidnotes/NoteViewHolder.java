package com.example.androidnotes;

import android.nfc.Tag;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class NoteViewHolder extends RecyclerView.ViewHolder {
    private static final String TAG = "NoteViewHolder";
    public TextView title;
    public TextView content;
    public TextView dateTime;

    NoteViewHolder(View view){
        super(view);
        title = view.findViewById(R.id.title);
        //Log.d(TAG,view.findViewById(R.id.title));
        content = view.findViewById(R.id.content);
        dateTime = view.findViewById(R.id.dateTime);
        //title = (TextView)view.findViewById(R.id.title);
        //content = (TextView)view.findViewById(R.id.content);
        //dateTime = (TextView)view.findViewById(R.id.dateTime);


    }
}
