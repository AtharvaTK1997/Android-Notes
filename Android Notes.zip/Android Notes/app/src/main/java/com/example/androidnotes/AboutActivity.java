package com.example.androidnotes;

import android.os.Bundle;


import androidx.appcompat.app.AppCompatActivity;

import android.widget.TextView;

public class AboutActivity extends AppCompatActivity {

    TextView multinotepadtv, copyrighttv, versiontv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        multinotepadtv = findViewById(R.id.AndroidNotes);
        copyrighttv = findViewById(R.id.CR);
        versiontv = findViewById(R.id.ver);
    }
}