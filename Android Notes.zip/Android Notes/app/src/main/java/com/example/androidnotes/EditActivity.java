package com.example.androidnotes;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

public class EditActivity extends AppCompatActivity {
    EditText titlenew, contentnew;
    private Notes notes;
    private static final String TAG = "EditActivity";
    private String beforeT = "",beforeD = "", afterT="",afterD="";
    private int pos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        titlenew = findViewById(R.id.titlenew);
        contentnew = findViewById(R.id.contentnew);

        titlenew.setTextIsSelectable(true);
        contentnew.setTextIsSelectable(true);
        contentnew.setMovementMethod(new ScrollingMovementMethod());

        Intent data = getIntent();
        if (data.hasExtra("noteData"))
        {
            notes = (Notes) data.getSerializableExtra("noteData");
            if (notes != null)
            {
                titlenew.setText(notes.getTitle());
                contentnew.setText(notes.getContent());
                beforeT = notes.getTitle();
                beforeD = notes.getContent();
            }
        }

        if (data.hasExtra("position"))
        {
            pos = data.getIntExtra("position",-1);
        }

    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_edit_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.savenote:
                if (titlenew.getText().toString().equals("") && contentnew.getText().toString().equals(""))
                {
                    Toast.makeText(this,getString(R.string.noNotes),Toast.LENGTH_LONG).show();

                    finish();

                }
                else if (titlenew.getText().toString().equals(""))
                {
                    //Toast.makeText(this,getString(R.string.noTitle),Toast.LENGTH_LONG).show();
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);

                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            finish();
                        }

                    });
                    builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            Toast.makeText(EditActivity.this,"Enter title to save",Toast.LENGTH_LONG).show();
                        }
                    });

                    builder.setMessage("Note without title cant be saved. ");
                    AlertDialog dialog = builder.create();
                    dialog.show();
                    //finish();
                }

                else
                {
                    if(detectChange())
                        saveDate();
                    else
                        finish();
                }
                break;
            default:
                Toast.makeText(this,"Invalid Option",Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }

    public boolean detectChange()
    {
        afterT = titlenew.getText().toString();
        afterD = contentnew.getText().toString();

        if(beforeT.equals("") && beforeD.equals("") && afterT.equals("") && afterD.equals(""))
            return false;

        else if(!beforeT.equals(afterT) || !beforeD.equals(afterD))
            return true;
        else
            return false;
    }

    @Override
    public void onBackPressed() {

        if (!titlenew.getText().toString().equals("") && detectChange()) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    if(detectChange()){
                        saveDate();
                    }
                    else{
                        finish();
                    }
                }
            });
            builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    finish();
                }
            });

            builder.setMessage("Your note is not saved! Save note '"+titlenew.getText().toString()+"'");
            AlertDialog dialog = builder.create();
            dialog.show();
        }
        else if(detectChange() && titlenew.getText().toString().equals("")){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    finish();
                }

            });
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    Toast.makeText(EditActivity.this, "Enter title to save", Toast.LENGTH_SHORT).show();
                }
            });

            builder.setMessage("Note without title cant be saved. ");
            AlertDialog dialog = builder.create();
            dialog.show();
        }
        else{
            super.onBackPressed();
        }
    }

    public void saveDate()
    {
        Date d = new Date();
        SimpleDateFormat ft = new SimpleDateFormat ("E MMM dd',' hh:mm a ");

        Intent data = new Intent();
        data.putExtra("title", titlenew.getText().toString());
        data.putExtra("content",contentnew.getText().toString());
        data.putExtra("date",ft.format(d));
        if(pos!=-1)
            data.putExtra("position",pos);
        setResult(RESULT_OK,data);
        Log.d(TAG, "saveDate: "+ data);
        Toast.makeText(this,"Saved",Toast.LENGTH_SHORT).show();
        finish();
    }
}