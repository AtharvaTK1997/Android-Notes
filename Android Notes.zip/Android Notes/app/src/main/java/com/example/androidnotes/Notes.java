package com.example.androidnotes;

import java.io.Serializable;

public class Notes implements Serializable {

    private String title;
    private String content;
    private String date;
    private static int ctr = 1;

    public Notes() {
        this.title = "";
        this.content = "";
        this.date = "";
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "Notes{" +
                "title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", date='" + date + '\'' +
                '}';
    }
}
