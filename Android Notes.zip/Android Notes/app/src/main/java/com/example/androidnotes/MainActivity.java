package com.example.androidnotes;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.activity.result.ActivityResultLauncher;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.JsonReader;
import android.util.JsonWriter;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, View.OnLongClickListener{

    private final ArrayList<Notes> notesList = new ArrayList<>();  // Notes will be stored here
    private RecyclerView recyclernotes; // Layout's recyclerview
    private NoteAdapter mAdapter; // Data to recyclerview adapter
    private static final int SAVE_NT = 1, EDIT_NT = 2;
    private static final String TAG = "MainActivity";
    private ActivityResultLauncher<Intent> activitySaveResultLauncher, activityEditResultLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclernotes = findViewById(R.id.recycler);
        mAdapter = new NoteAdapter(notesList, this);
        recyclernotes.setAdapter(mAdapter);
        recyclernotes.setLayoutManager(new LinearLayoutManager(this));
        Log.d(TAG, "onCreate: "+ notesList);
        activitySaveResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if(result.getResultCode() == EditActivity.RESULT_OK){
                            Intent data = result.getData();
                            doSomeoperation(SAVE_NT,data);
                        }
                    }
                }
        );

        activityEditResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if(result.getResultCode() == EditActivity.RESULT_OK){
                            Intent data = result.getData();
                            doSomeoperation(EDIT_NT,data);
                        }
                    }
                }
        );

        loadFile();
        changeTitle();

    }

    public void changeTitle()
    {
        int totalNotes = notesList.size();
        if (totalNotes != 0)
            setTitle(getString(R.string.app_name)+ " [" + totalNotes + "]");
        else
            setTitle(getString(R.string.app_name));
    }

    @Override
    public void onClick(View v) {
        int pos = recyclernotes.getChildLayoutPosition(v);
        Notes notes = notesList.get(pos);
        Intent data = new Intent(this, EditActivity.class);
        data.putExtra("noteData", notes);
        data.putExtra("position", pos);
        activityEditResultLauncher.launch(data);
        //startActivityForResult(data,EDIT_NT);
        //startActivity(data,EDIT_NT);
        //activityResultLauncher.launch(data);
    }

    // From OnLongClickListener
    @Override
    public boolean onLongClick(View v) {  // long click listener called by ViewHolder long clicks
        final int pos = recyclernotes.getChildLayoutPosition(v);
        final Notes m = notesList.get(pos);
        // Toast.makeText(v.getContext(), "LONG " + m.toString(), Toast.LENGTH_SHORT).show();

        // Simple Ok & Cancel dialog - no view used.
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        //builder.setIcon(R.drawable.icon1);

        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                notesList.remove(pos);
                mAdapter.notifyDataSetChanged();
                changeTitle();
            }
        });
        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {

            }
        });

        builder.setMessage("Are you sure want to delete '"+notesList.get(pos).getTitle()+"'");
        //builder.setTitle("Yes/No Dialog");

        AlertDialog dialog = builder.create();
        dialog.show();
        return false;
    }

    private void loadFile() {

        Log.d(TAG, "loadFile: Loading JSON File");
        try {
            InputStream is = getApplicationContext().openFileInput(getString(R.string.file_name));
            JsonReader reader = new JsonReader(new InputStreamReader(is, StandardCharsets.UTF_8));

            reader.beginArray();
            while (reader.hasNext())
            {
                Notes n = new Notes();
                reader.beginObject();
                while (reader.hasNext())
                {
                    String name = reader.nextName();
                    switch (name)
                    {
                        case "title":
                            n.setTitle(reader.nextString());
                            break;
                        case "content":
                            n.setContent(reader.nextString());
                            break;
                        case "date":
                            n.setDate(reader.nextString());
                            break;
                        default:
                            reader.skipValue();
                            break;
                    }
                }
                reader.endObject();
                Log.d(TAG, "loadFile: File gets Load Load in Array" + n);
                notesList.add(n);
            }
            reader.endArray();
        }
        catch (FileNotFoundException e) {
            Toast.makeText(this, getString(R.string.no_file), Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.aboutinfo:
                Toast.makeText(this, "About Information", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, AboutActivity.class);
                startActivity(intent);
                return true;
            case R.id.addnotes:
                Toast.makeText(this, "Add new Notes", Toast.LENGTH_SHORT).show();
                Intent intent2 = new Intent(this, EditActivity.class);
                activitySaveResultLauncher.launch(intent2);
                //startActivityForResult(intent2,SAVE_NT);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main_menu, menu);
        return true;
    }

    protected void doSomeoperation(int requestCode, @Nullable Intent data){
        try {
            switch (requestCode) {
                case SAVE_NT:
                    Notes note = new Notes();
                    assert data != null;
                    note.setTitle(data.getStringExtra("title"));
                    note.setContent(data.getStringExtra("content"));
                    note.setDate(data.getStringExtra("date"));
                    Log.d(TAG, "onActivityResult: "+note);
                    notesList.add(0, note);
                    mAdapter.notifyDataSetChanged();
                    break;
                case EDIT_NT:
                    Notes notes = new Notes();
                    assert data != null;
                    notes.setTitle(data.getStringExtra("title"));
                    notes.setContent(data.getStringExtra("content"));
                    notes.setDate(data.getStringExtra("date"));
                    notesList.remove(data.getIntExtra("position", -1));
                    notesList.add(0, notes);
                    mAdapter.notifyDataSetChanged();
                    break;
                default:
                    Log.d(TAG, "onActivityResult: Request Code" + requestCode);
            }
        } catch (Exception e) {
            Toast.makeText(this, "Null Pointer encountered.", Toast.LENGTH_SHORT).show();
        }
    }

//    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
//        super.onActivityResult(requestCode, resultCode, data);
//        try {
//            switch (requestCode) {
//                case SAVE_NT:
//                    if (resultCode == RESULT_OK) {
//                        Notes note = new Notes();
//                        assert data != null;
//                        note.setTitle(data.getStringExtra("title"));
//                        note.setContent(data.getStringExtra("content"));
//                        note.setDate(data.getStringExtra("date"));
//                        Log.d(TAG, "onActivityResult: "+note);
//                        notesList.add(0, note);
//                        mAdapter.notifyDataSetChanged();
//                    }
//                    break;
//                case EDIT_NT:
//                    if (resultCode == RESULT_OK) {
//                        Notes note = new Notes();
//                        assert data != null;
//                        note.setTitle(data.getStringExtra("title"));
//                        note.setContent(data.getStringExtra("content"));
//                        note.setDate(data.getStringExtra("date"));
//                        notesList.remove(data.getIntExtra("position", -1));
//                        notesList.add(0, note);
//                        mAdapter.notifyDataSetChanged();
//                    }
//                    break;
//                default:
//                    Log.d(TAG, "onActivityResult: Request Code" + requestCode);
//            }
//        } catch (Exception e) {
//            Toast.makeText(this, "Null Pointer encountered.", Toast.LENGTH_SHORT).show();
//        }
//    }

    @Override
    protected void onResume()
    {
        changeTitle();
        super.onResume();
    }

    protected void onPause() {
        super.onPause();
        saveNotes();

    }

    private void saveNotes() {

        Log.d(TAG, "saveNote: Saving JSON File");
        try {
            FileOutputStream fos = getApplicationContext().
                    openFileOutput(getString(R.string.file_name), Context.MODE_PRIVATE);

            JsonWriter writer = new JsonWriter(new OutputStreamWriter(fos, getString(R.string.encoding)));
            writer.setIndent("  ");
            writer.beginArray();
            for (Notes n : notesList)
            {
                writer.beginObject();
                writer.name("title").value(n.getTitle());
                Log.d(TAG, "saveNotes: "+n.getContent()+ n.getTitle());
                writer.name("content").value(n.getContent());
                writer.name("date").value(n.getDate());
                writer.endObject();
            }
            writer.endArray();
            writer.close();
        } catch (Exception e) {
            e.getStackTrace();
        }
    }

    @Override
    public void onBackPressed() {
        Toast.makeText(this, "The back button was pressed - Bye!", Toast.LENGTH_SHORT).show();
        super.onBackPressed();
    }
}