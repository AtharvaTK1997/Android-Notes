package com.example.androidnotes;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class NoteAdapter extends RecyclerView.Adapter<NoteViewHolder>{
    private static final String TAG = "NoteAdapter";
    private List<Notes> notesList;
    private MainActivity mainAct;

    NoteAdapter(List<Notes> noteList, MainActivity ma) {
        this.notesList = noteList;
        this.mainAct = ma;
    }

    public NoteViewHolder onCreateViewHolder(@NonNull final ViewGroup parent, int viewType) {
        Log.d(TAG, "onCreateViewHolder: MAKING NEW NoteViewHolder");

        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.notes_list, parent, false);

        itemView.setOnClickListener(mainAct);
        itemView.setOnLongClickListener(mainAct);
        return new NoteViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull NoteViewHolder holder, int position) {
        Log.d(TAG, "onBindViewHolder: FILLING VIEW HOLDER Notes " + position);

        Notes note = notesList.get(position);

        if (note.getTitle().length() > 80){
            holder.title.setText(String.format("%s...", note.getTitle().substring(0, 80)));
        }
        else {
            holder.title.setText(note.getTitle());
        }

        if (note.getContent().length() > 80){

            holder.content.setText(String.format("%s...", note.getContent().substring(0, 80)));
            Log.d(TAG, "onBindViewHolder: "+ holder.content);
        }
        else {
            holder.content.setText(note.getContent());
        }
        holder.dateTime.setText(note.getDate());
    }

    @Override
    public int getItemCount() {
        Log.d(TAG, "getItemCount: ");
        return notesList.size();
    }
}
